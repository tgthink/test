<template>
  <div>
    <h2>ABOUT US...</h2>
    <div style="height:1000px; border: 1px solid #f00">
      This long div is for testing { saveScrollPosition: true } in html5 mode
    </div>
    <p id="anchor">This anchor is for testing anchor scrolling in html5 mode</p>
  </div>
</template>
