## Deprecated

See [vue-loader-example](https://github.com/vuejs/vue-loader-example) instead.
