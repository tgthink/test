require('./style.styl')

module.exports = {
  template: require('./template.html'),
  props: ['msg']
}