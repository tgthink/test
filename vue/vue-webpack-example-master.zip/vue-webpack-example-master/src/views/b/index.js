module.exports = {
  template: require('./template.html'),
  replace: true
}